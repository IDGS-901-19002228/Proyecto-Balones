﻿namespace IDGS901_API_Balones.Models
{
    public class Perfil
    {
    }
}
