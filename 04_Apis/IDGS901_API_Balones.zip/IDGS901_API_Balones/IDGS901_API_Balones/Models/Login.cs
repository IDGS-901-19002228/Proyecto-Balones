﻿namespace IDGS901_API_Balones.Models
{
    public class Login
    {
        public string Usuario { get; set; }
        public string Contrasenia { get; set; }
    }

}
