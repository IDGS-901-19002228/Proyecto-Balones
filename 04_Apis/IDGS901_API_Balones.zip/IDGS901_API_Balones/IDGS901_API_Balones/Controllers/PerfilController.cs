﻿using Microsoft.AspNetCore.Mvc;

namespace IDGS901_API_Balones.Controllers
{
    public class PerfilController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
